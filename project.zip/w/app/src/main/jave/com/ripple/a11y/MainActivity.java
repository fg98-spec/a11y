package com.ripple.a11y;

import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.pm.ServiceInfo;
import android.content.res.XmlResourceParser;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.util.Xml;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;
import org.xmlpull.v1.XmlPullParser;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private static final String ANDROID_NS = "http://schemas.android.com/apk/res/android";
    private static final String A11Y_ACTION = "android.accessibilityservice.AccessibilityService";
    private static final String A11Y_META = "android.accessibilityservice";

    private WebView web;
    private PackageManager pm;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pm = getPackageManager();

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);

        web.setBackgroundColor(0xFF141218);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "A11yBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void push(final String fn, JSONObject data) {
        final String lit = JSONObject.quote(data.toString());
        ui.post(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window." + fn + "(JSON.parse(" + lit + "))", null);
            }
        });
    }

    private boolean hasWrite() {
        try {
            return checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) { return false; }
    }

    private String enabledRaw() {
        try {
            String v = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return v == null ? "" : v;
        } catch (Throwable t) { return ""; }
    }

    private JSONArray enabledArr() {
        JSONArray a = new JSONArray();
        String[] parts = enabledRaw().split(":");
        for (int i = 0; i < parts.length; i++) {
            String t = parts[i].trim();
            if (t.length() == 0) continue;
            ComponentName cn = ComponentName.unflattenFromString(t);
            if (cn != null) a.put(cn.flattenToString());
        }
        return a;
    }

    private boolean masterOn() {
        try {
            return Settings.Secure.getInt(getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1;
        } catch (Throwable t) { return false; }
    }

    private JSONObject state() {
        JSONObject o = new JSONObject();
        try {
            o.put("enabled", enabledArr());
            o.put("master", masterOn());
            o.put("write", hasWrite());
            o.put("grantCmd", "pm grant " + getPackageName()
                    + " android.permission.WRITE_SECURE_SETTINGS");
        } catch (Throwable t) {}
        return o;
    }

    private String iconOf(String pkg, int size) {
        try {
            Drawable d = pm.getApplicationIcon(pkg);
            Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 90, o);
            return "data:image/png;base64,"
                    + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) { return ""; }
    }

    private List<ResolveInfo> queryServices() {
        try {
            Intent q = new Intent(A11Y_ACTION);
            List<ResolveInfo> r = pm.queryIntentServices(q, PackageManager.GET_META_DATA);
            if (r != null) return r;
        } catch (Throwable t) {}
        return new java.util.ArrayList<ResolveInfo>();
    }

    private void readMeta(ServiceInfo si, JSONArray caps, JSONArray scope, String[] descOut) {
        XmlResourceParser x = null;
        try {
            x = si.loadXmlMetaData(pm, A11Y_META);
            if (x == null) return;
            int type;
            do {
                type = x.next();
            } while (type != XmlPullParser.START_TAG && type != XmlPullParser.END_DOCUMENT);
            if (type != XmlPullParser.START_TAG) return;

            if (x.getAttributeBooleanValue(ANDROID_NS, "canRetrieveWindowContent", false))
                caps.put("screen");
            if (x.getAttributeBooleanValue(ANDROID_NS, "canPerformGestures", false))
                caps.put("gesture");
            if (x.getAttributeBooleanValue(ANDROID_NS, "canRequestFilterKeyEvents", false))
                caps.put("keys");
            if (x.getAttributeBooleanValue(ANDROID_NS, "canRequestTouchExplorationMode", false))
                caps.put("touch");

            int f = x.getAttributeIntValue(ANDROID_NS, "accessibilityFlags", 0);
            if ((f & 0x00000010) != 0) caps.put("ids");
            if ((f & 0x00000040) != 0) caps.put("windows");

            String pk = x.getAttributeValue(ANDROID_NS, "packageNames");
            if (pk != null) {
                String[] arr = pk.split(",");
                for (int i = 0; i < arr.length; i++) {
                    String v = arr[i].trim();
                    if (v.length() > 0) scope.put(v);
                }
            }

            String d = x.getAttributeValue(ANDROID_NS, "description");
            if (d != null && d.startsWith("@")) {
                try {
                    int id = Integer.parseInt(d.substring(1));
                    CharSequence cs = pm.getText(si.packageName, id, si.applicationInfo);
                    if (cs != null) descOut[0] = cs.toString();
                } catch (Throwable t) {}
            } else if (d != null) {
                descOut[0] = d;
            }
        } catch (Throwable t) {
        } finally {
            if (x != null) { try { x.close(); } catch (Throwable t) {} }
        }
    }

    public class Bridge {

        @JavascriptInterface
        public void requestBoot() {
            io.execute(new Runnable() {
                @Override public void run() {
                    JSONObject root = new JSONObject();
                    try {
                        JSONObject dev = new JSONObject();
                        dev.put("model", Build.MODEL);
                        dev.put("brand", Build.BRAND);
                        dev.put("release", Build.VERSION.RELEASE);
                        dev.put("sdk", Build.VERSION.SDK_INT);
                        root.put("device", dev);
                        root.put("self", getPackageName());
                        root.put("state", state());

                        JSONArray svcs = new JSONArray();
                        HashMap<String, Integer> cnt = new HashMap<String, Integer>();
                        List<ResolveInfo> list = queryServices();
                        for (int i = 0; i < list.size(); i++) {
                            ResolveInfo ri = list.get(i);
                            if (ri == null) continue;
                            ServiceInfo si = ri.serviceInfo;
                            if (si == null || si.applicationInfo == null) continue;
                            ApplicationInfo ai = si.applicationInfo;

                            Integer c = cnt.get(si.packageName);
                            cnt.put(si.packageName, c == null ? 1 : c.intValue() + 1);

                            JSONArray caps = new JSONArray();
                            JSONArray scope = new JSONArray();
                            String[] desc = new String[]{""};
                            readMeta(si, caps, scope, desc);

                            JSONObject o = new JSONObject();
                            o.put("pkg", si.packageName);
                            o.put("cls", si.name);
                            o.put("flat", new ComponentName(si.packageName, si.name).flattenToString());
                            o.put("app", String.valueOf(ai.loadLabel(pm)));
                            o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                            o.put("caps", caps);
                            o.put("scope", scope);
                            o.put("desc", desc[0] == null ? "" : desc[0]);
                            o.put("icon", iconOf(si.packageName, 80));
                            svcs.put(o);
                        }
                        root.put("services", svcs);

                        JSONArray apps = new JSONArray();
                        List<ApplicationInfo> all = pm.getInstalledApplications(0);
                        if (all != null) {
                            for (int i = 0; i < all.size(); i++) {
                                ApplicationInfo ai = all.get(i);
                                JSONObject o = new JSONObject();
                                o.put("pkg", ai.packageName);
                                o.put("name", String.valueOf(ai.loadLabel(pm)));
                                o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                                o.put("enabledApp", ai.enabled);
                                Integer c = cnt.get(ai.packageName);
                                o.put("a11y", c == null ? 0 : c.intValue());
                                String ver = "";
                                long up = 0, fi = 0;
                                try {
                                    android.content.pm.PackageInfo pi = pm.getPackageInfo(ai.packageName, 0);
                                    ver = pi.versionName == null ? "" : pi.versionName;
                                    up = pi.lastUpdateTime;
                                    fi = pi.firstInstallTime;
                                } catch (Throwable t) {}
                                o.put("ver", ver);
                                o.put("update", up);
                                o.put("first", fi);
                                apps.put(o);
                            }
                        }
                        root.put("apps", apps);
                    } catch (Throwable t) {
                        try { root.put("err", String.valueOf(t)); } catch (Throwable x) {}
                    }
                    push("__boot", root);
                }
            });
        }

        @JavascriptInterface
        public void requestState() {
            io.execute(new Runnable() {
                @Override public void run() { push("__state", state()); }
            });
        }

        @JavascriptInterface
        public String icon(String pkg) { return iconOf(pkg, 72); }

        @JavascriptInterface
        public void apply(final String id, final String csv) {
            io.execute(new Runnable() {
                @Override public void run() {
                    JSONObject r = new JSONObject();
                    try {
                        Settings.Secure.putString(getContentResolver(),
                                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, csv);
                        Settings.Secure.putInt(getContentResolver(),
                                Settings.Secure.ACCESSIBILITY_ENABLED, csv.length() == 0 ? 0 : 1);
                        r.put("ok", true);
                    } catch (Throwable t) {
                        try {
                            r.put("ok", false);
                            r.put("err", "没有写入权限，请先在 Shizuku 执行授权命令");
                        } catch (Throwable x) {}
                    }
                    try { r.put("id", id); r.put("state", state()); } catch (Throwable x) {}
                    push("__apply", r);
                }
            });
        }

        @JavascriptInterface
        public void setMaster(final boolean on) {
            io.execute(new Runnable() {
                @Override public void run() {
                    try {
                        Settings.Secure.putInt(getContentResolver(),
                                Settings.Secure.ACCESSIBILITY_ENABLED, on ? 1 : 0);
                    } catch (Throwable t) {}
                    push("__state", state());
                }
            });
        }

        @JavascriptInterface
        public void openApp(final String pkg) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void launchApp(final String pkg) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = pm.getLaunchIntentForPackage(pkg);
                        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void openA11y() {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void openShizuku() {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api");
                        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        else startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://shizuku.rikka.app/"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("a11y", text));
                    } catch (Throwable t) {}
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (web != null) { web.removeJavascriptInterface("A11yBridge"); web.destroy(); }
        super.onDestroy();
    }
}