package com.ripple.a11y;

import android.accessibilityservice.AccessibilityServiceInfo;
import android.app.Activity;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.Base64;
import android.view.accessibility.AccessibilityManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {

    private WebView web;
    private PackageManager pm;
    private AccessibilityManager am;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        pm = getPackageManager();
        am = (AccessibilityManager) getSystemService(Context.ACCESSIBILITY_SERVICE);

        web = new WebView(this);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);

        web.setBackgroundColor(0xFF141218);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "A11yBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void push(String fn, JSONObject data) {
        final String lit = JSONObject.quote(data.toString());
        ui.post(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window." + fn + "(JSON.parse(" + lit + "))", null);
            }
        });
    }

    private boolean hasWrite() {
        return checkSelfPermission("android.permission.WRITE_SECURE_SETTINGS")
                == PackageManager.PERMISSION_GRANTED;
    }

    private String enabledRaw() {
        try {
            String v = Settings.Secure.getString(getContentResolver(),
                    Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
            return v == null ? "" : v;
        } catch (Throwable t) { return ""; }
    }

    private JSONArray enabledArr() {
        JSONArray a = new JSONArray();
        String[] parts = enabledRaw().split(":");
        for (String p : parts) {
            String t = p.trim();
            if (t.length() == 0) continue;
            ComponentName cn = ComponentName.unflattenFromString(t);
            if (cn != null) a.put(cn.flattenToString());
        }
        return a;
    }

    private boolean master() {
        try {
            return Settings.Secure.getInt(getContentResolver(),
                    Settings.Secure.ACCESSIBILITY_ENABLED, 0) == 1;
        } catch (Throwable t) { return false; }
    }

    private JSONObject state() {
        JSONObject o = new JSONObject();
        try {
            o.put("enabled", enabledArr());
            o.put("master", master());
            o.put("write", hasWrite());
            o.put("grantCmd", "pm grant " + getPackageName()
                    + " android.permission.WRITE_SECURE_SETTINGS");
        } catch (Throwable t) {}
        return o;
    }

    private String iconOf(String pkg, int size) {
        try {
            Drawable d = pm.getApplicationIcon(pkg);
            Bitmap b = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(b);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            b.compress(Bitmap.CompressFormat.PNG, 90, o);
            return "data:image/png;base64,"
                    + Base64.encodeToString(o.toByteArray(), Base64.NO_WRAP);
        } catch (Throwable t) { return ""; }
    }

    private JSONArray caps(AccessibilityServiceInfo i) {
        JSONArray a = new JSONArray();
        if (i.canRetrieveWindowContent) a.put("screen");
        if ((i.flags & AccessibilityServiceInfo.FLAG_REQUEST_FILTER_KEY_EVENTS) != 0) a.put("keys");
        if ((i.flags & AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS) != 0) a.put("ids");
        if ((i.flags & AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS) != 0) a.put("windows");
        if ((i.flags & AccessibilityServiceInfo.FLAG_REQUEST_TOUCH_EXPLORATION_MODE) != 0) a.put("touch");
        try { if (i.canPerformGestures()) a.put("gesture"); } catch (Throwable t) {}
        return a;
    }

    public class Bridge {

        @JavascriptInterface
        public void requestBoot() {
            io.execute(new Runnable() {
                @Override public void run() {
                    JSONObject root = new JSONObject();
                    try {
                        JSONObject dev = new JSONObject();
                        dev.put("model", Build.MODEL);
                        dev.put("brand", Build.BRAND);
                        dev.put("release", Build.VERSION.RELEASE);
                        dev.put("sdk", Build.VERSION.SDK_INT);
                        root.put("device", dev);
                        root.put("self", getPackageName());
                        root.put("state", state());

                        JSONArray svcs = new JSONArray();
                        HashMap<String, Integer> cnt = new HashMap<String, Integer>();
                        List<AccessibilityServiceInfo> list = am.getInstalledAccessibilityServiceList();
                        if (list != null) {
                            for (AccessibilityServiceInfo info : list) {
                                if (info.resolveInfo == null) continue;
                                android.content.pm.ServiceInfo si = info.resolveInfo.serviceInfo;
                                if (si == null || si.applicationInfo == null) continue;
                                ApplicationInfo ai = si.applicationInfo;
                                Integer c = cnt.get(si.packageName);
                                cnt.put(si.packageName, c == null ? 1 : c + 1);

                                JSONObject o = new JSONObject();
                                o.put("pkg", si.packageName);
                                o.put("cls", si.name);
                                o.put("flat", new ComponentName(si.packageName, si.name).flattenToString());
                                o.put("app", String.valueOf(ai.loadLabel(pm)));
                                o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                                o.put("caps", caps(info));
                                JSONArray sc = new JSONArray();
                                if (info.packageNames != null)
                                    for (String p : info.packageNames) sc.put(p);
                                o.put("scope", sc);
                                String d = null;
                                try { d = String.valueOf(info.loadDescription(pm)); } catch (Throwable t) {}
                                o.put("desc", d == null || "null".equals(d) ? "" : d);
                                o.put("icon", iconOf(si.packageName, 80));
                                svcs.put(o);
                            }
                        }
                        root.put("services", svcs);

                        JSONArray apps = new JSONArray();
                        List<ApplicationInfo> all = pm.getInstalledApplications(0);
                        if (all != null) {
                            for (ApplicationInfo ai : all) {
                                JSONObject o = new JSONObject();
                                o.put("pkg", ai.packageName);
                                o.put("name", String.valueOf(ai.loadLabel(pm)));
                                o.put("system", (ai.flags & ApplicationInfo.FLAG_SYSTEM) != 0);
                                o.put("enabledApp", ai.enabled);
                                Integer c = cnt.get(ai.packageName);
                                o.put("a11y", c == null ? 0 : c);
                                String ver = "";
                                long up = 0, fi = 0;
                                try {
                                    android.content.pm.PackageInfo pi = pm.getPackageInfo(ai.packageName, 0);
                                    ver = pi.versionName == null ? "" : pi.versionName;
                                    up = pi.lastUpdateTime; fi = pi.firstInstallTime;
                                } catch (Throwable t) {}
                                o.put("ver", ver);
                                o.put("update", up);
                                o.put("first", fi);
                                apps.put(o);
                            }
                        }
                        root.put("apps", apps);
                    } catch (Throwable t) {
                        try { root.put("err", String.valueOf(t)); } catch (Throwable x) {}
                    }
                    push("__boot", root);
                }
            });
        }

        @JavascriptInterface
        public void requestState() {
            io.execute(new Runnable() {
                @Override public void run() { push("__state", state()); }
            });
        }

        @JavascriptInterface
        public String icon(final String pkg) { return iconOf(pkg, 72); }

        @JavascriptInterface
        public void apply(final String id, final String csv) {
            io.execute(new Runnable() {
                @Override public void run() {
                    JSONObject r = new JSONObject();
                    try {
                        Settings.Secure.putString(getContentResolver(),
                                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES, csv);
                        Settings.Secure.putInt(getContentResolver(),
                                Settings.Secure.ACCESSIBILITY_ENABLED, csv.length() == 0 ? 0 : 1);
                        r.put("ok", true);
                    } catch (Throwable t) {
                        try {
                            r.put("ok", false);
                            r.put("err", "没有写入权限。请在 Shizuku 终端执行授权命令后重试。");
                        } catch (Throwable x) {}
                    }
                    try { r.put("id", id); r.put("state", state()); } catch (Throwable x) {}
                    push("__apply", r);
                }
            });
        }

        @JavascriptInterface
        public void setMaster(final boolean on) {
            io.execute(new Runnable() {
                @Override public void run() {
                    try {
                        Settings.Secure.putInt(getContentResolver(),
                                Settings.Secure.ACCESSIBILITY_ENABLED, on ? 1 : 0);
                    } catch (Throwable t) {}
                    push("__state", state());
                }
            });
        }

        @JavascriptInterface
        public void openApp(final String pkg) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + pkg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void launchApp(final String pkg) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = pm.getLaunchIntentForPackage(pkg);
                        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void openA11y() {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void openShizuku() {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        Intent i = pm.getLaunchIntentForPackage("moe.shizuku.privileged.api");
                        if (i != null) startActivity(i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        else startActivity(new Intent(Intent.ACTION_VIEW,
                                Uri.parse("https://shizuku.rikka.app/"))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
        }

        @JavascriptInterface
        public void copy(final String text) {
            ui.post(new Runnable() {
                @Override public void run() {
                    try {
                        ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                        cm.setPrimaryClip(ClipData.newPlainText("a11y", text));
                    } catch (Throwable t) {}
                }
            });
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        io.shutdownNow();
        if (web != null) { web.removeJavascriptInterface("A11yBridge"); web.destroy(); }
        super.onDestroy();
    }
}