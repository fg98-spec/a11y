// app/src/main/java/com/ripple/cine/MainActivity.java
package com.ripple.cine;

import android.app.Activity;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import org.json.JSONObject;

public class MainActivity extends Activity {

    private WebView web;
    private final Handler ui = new Handler(Looper.getMainLooper());
    static final String QQ_PKG = "com.tencent.qqlive";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.parseColor("#07090C"));
        getWindow().setNavigationBarColor(Color.parseColor("#0B0E13"));
        web = new WebView(this);
        setContentView(web);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(false);
        web.setBackgroundColor(Color.parseColor("#07090C"));
        web.setOverScrollMode(View.OVER_SCROLL_NEVER);
        web.setWebViewClient(new WebViewClient());
        web.addJavascriptInterface(new Bridge(), "CineBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    private void push(final String fn, JSONObject d) {
        final String lit = JSONObject.quote(d.toString());
        ui.post(new Runnable() {
            @Override public void run() {
                web.evaluateJavascript("window." + fn + "(JSON.parse(" + lit + "))", null);
            }
        });
    }

    private boolean hasQQ() {
        try { getPackageManager().getPackageInfo(QQ_PKG, 0); return true; }
        catch (Throwable t) { return false; }
    }

    /** mode: screen=内置官方页 / app=腾讯视频客户端 / browser=系统浏览器 */
    private void open(String url, String mode) {
        if (url == null || url.length() == 0) return;
        if ("app".equals(mode)) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.setPackage(QQ_PKG);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            } catch (Throwable t) { /* 落到内置 */ }
        }
        if ("browser".equals(mode)) {
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse(url));
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return;
            } catch (Throwable t) { /* 落到内置 */ }
        }
        try {
            Intent i = new Intent(this, ScreenActivity.class);
            i.putExtra("url", url);
            startActivity(i);
        } catch (Throwable t) {
            try {
                startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Throwable x) {}
        }
    }

    public class Bridge {
        @JavascriptInterfaceBoot
        public void boot() {}

        @android.webkit.JavascriptInterface
        public void requestBoot() {
            JSONObject o = new JSONObject();
            try {
                JSONObject d = new JSONObject();
                d.put("model", Build.MODEL);
                d.put("brand", Build.BRAND);
                d.put("release", Build.VERSION.RELEASE);
                d.put("sdk", Build.VERSION.SDK_INT);
                o.put("device", d);
                o.put("self", getPackageName());
                o.put("hasQQ", hasQQ());
                o.put("native", true);
            } catch (Throwable t) {}
            push("__boot", o);
        }

        @android.webkit.JavascriptInterface
        public void play(String url, String mode) { open(url, mode); }

        @android.webkit.JavascriptInterface
        public void openUrl(String url) { open(url, "browser"); }

        @android.webkit.JavascriptInterface
        public void copy(String text) {
            try {
                ClipboardManager cm = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                cm.setPrimaryClip(ClipData.newPlainText("muguang", text));
            } catch (Throwable t) {}
        }

        @android.webkit.JavascriptInterface
        public void share(String text) {
            try {
                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_TEXT, text);
                startActivity(Intent.createChooser(i, "分享").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
            } catch (Throwable t) {}
        }

        @android.webkit.JavascriptInterface
        public void buzz(int ms) {
            try {
                android.os.Vibrator v = (android.os.Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
                if (v != null) v.vibrate(ms <= 0 ? 10 : ms);
            } catch (Throwable t) {}
        }
    }

    /** 承载腾讯视频官方页面的放映厅；不做任何解析、注入或解锁。 */
    public static class ScreenActivity extends Activity {
        private WebView w;
        private ProgressBar bar;
        private TextView addr;

        @Override
        protected void onCreate(Bundle b) {
            super.onCreate(b);
            getWindow().setStatusBarColor(Color.parseColor("#07090C"));
            getWindow().setNavigationBarColor(Color.parseColor("#0B0E13"));

            LinearLayout root = new LinearLayout(this);
            root.setOrientation(LinearLayout.VERTICAL);
            root.setBackgroundColor(Color.parseColor("#07090C"));

            LinearLayout top = new LinearLayout(this);
            top.setOrientation(LinearLayout.HORIZONTAL);
            top.setGravity(Gravity.CENTER_VERTICAL);
            top.setBackgroundColor(Color.parseColor("#12151C"));
            int pad = dp(10);
            top.setPadding(pad, pad, pad, pad);

            TextView close = mkBtn("关闭");
            close.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finish(); }
            });
            top.addView(close);

            addr = new TextView(this);
            addr.setTextColor(Color.parseColor("#9BA9BD"));
            addr.setTextSize(11);
            addr.setSingleLine(true);
            addr.setEllipsize(android.text.TextUtils.TruncateAt.MIDDLE);
            LinearLayout.LayoutParams ap = new LinearLayout.LayoutParams(0,
                    ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            ap.leftMargin = dp(10); ap.rightMargin = dp(10);
            addr.setLayoutParams(ap);
            top.addView(addr);

            TextView ext = mkBtn("外部打开");
            ext.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    try {
                        startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(cur))
                                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Throwable t) {}
                }
            });
            top.addView(ext);

            root.addView(top, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            bar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
            bar.setMax(100);
            bar.setProgress(0);
            root.addView(bar, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, dp(3)));

            FrameLayout holder = new FrameLayout(this);
            w = new WebView(this);
            holder.addView(w, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            root.addView(holder, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            setContentView(root);

            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setDatabaseEnabled(true);
            s.setMediaPlaybackRequiresUserGesture(true);
            s.setSupportMultipleWindows(true);
            s.setJavaScriptCanOpenWindowsAutomatically(true);
            s.setMixedContentMode(WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE);
            s.setUseWideViewPort(true);
            s.setLoadWithOverviewMode(true);
            s.setSupportZoom(true);
            s.setBuiltInZoomControls(true);
            s.setDisplayZoomControls(false);
            w.setBackgroundColor(Color.parseColor("#07090C"));

            w.setWebChromeClient(new WebChromeClient() {
                @Override public void onProgressChanged(WebView v, int p) {
                    bar.setProgress(p);
                    bar.setVisibility(p >= 100 ? View.GONE : View.VISIBLE);
                }
            });
            w.setWebViewClient(new WebViewClient() {
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                    return handle(r.getUrl());
                }
                @SuppressWarnings("deprecation")
                @Override
                public boolean shouldOverrideUrlLoading(WebView v, String u) {
                    return handle(Uri.parse(u));
                }
                @Override public void onPageFinished(WebView v, String u) {
                    cur = u; addr.setText(u);
                }
            });

            cur = getIntent().getStringExtra("url");
            if (cur == null) cur = "https://v.qq.com/";
            addr.setText(cur);
            w.loadUrl(cur);
        }

        private String cur = "";

        private boolean handle(Uri u) {
            if (u == null) return false;
            String sc = u.getScheme();
            if (sc == null) return false;
            if ("http".equals(sc) || "https".equals(sc)) return false;
            try {
                Intent i = new Intent(Intent.ACTION_VIEW, u);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (ActivityNotFoundException e) {
            } catch (Throwable t) {}
            return true;
        }

        private TextView mkBtn(String t) {
            TextView v = new TextView(this);
            v.setText(t);
            v.setTextColor(Color.parseColor("#FFB43A"));
            v.setTextSize(13);
            v.setPadding(dp(12), dp(8), dp(12), dp(8));
            v.setBackgroundColor(Color.parseColor("#1D222C"));
            return v;
        }

        private int dp(int v) {
            return Math.round(v * getResources().getDisplayMetrics().density);
        }

        @Override public void onBackPressed() {
            if (w != null && w.canGoBack()) w.goBack(); else finish();
        }

        @Override protected void onPause() { if (w != null) w.onPause(); super.onPause(); }
        @Override protected void onResume() { if (w != null) w.onResume(); super.onResume(); }
        @Override protected void onDestroy() {
            if (w != null) { w.loadUrl("about:blank"); w.destroy(); w = null; }
            super.onDestroy();
        }
    }

    @Override public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (web != null) { web.removeJavascriptInterface("CineBridge"); web.destroy(); web = null; }
        super.onDestroy();
    }

    private @interface JavascriptInterfaceBoot {}
}